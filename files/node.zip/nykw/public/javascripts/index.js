/**
 * Created by gan on 14-9-25.
 */

var app = angular.module('app',[]);

app.factory('data', function ($http, $q) {
    var data_ = {};
    return {
        getAllItems: function () {
            var defer = $q.defer();
            $http.get('/items').success(function (data) {
                data_.items = data.data;
                console.log(data.data);
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {
                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            });
            return defer.promise;
        },
        createItem: function (item) {
            var defer = $q.defer();
            $http.post('/items', item).success(function (data) {
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {
                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            });
            return defer.promise;
        },
        deleteItem: function (itemId) {

            var defer = $q.defer();
            $http.delete('/items/' + itemId).success(function (data) {
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {

                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            })
            return defer.promise;
        },
        updateItem: function (item) {
            var defer = $q.defer();
            $http.put('/items', item).success(function (data) {

                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {

                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            })
            return defer.promise;
        },
        cacheItems: function () {

            return data_.items;
        },
        getCacheItem: function (id) {
            var cacheData = this.cacheItems();
            var length = cacheData.length;
            for (var i = 0; i < length; i++) {

                if (cacheData[i].id == id) {
                    return cacheData[i];
                }
            }
            return null;
        }
    };
});

app.controller('mainController', function ($scope,data,$timeout) {
    data.getAllItems().then(function (data) {
        if (data.type == 1) {
            $scope.items = data.data;
            $timeout(function () {
//                console.log($scope.items);
            }, 0);
        }
    })
});
