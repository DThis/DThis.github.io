/**
 * Created by gan on 14-9-19.
 */

var app = angular.module('app', ['ngRoute', 'ngCookies', 'ngImgCrop']);

app.run(function ($cookieStore, $rootScope, $location) {

    $rootScope.root = $rootScope.root || {};

    $rootScope.root.isLogin = function () {
        return $cookieStore.get('user') ? true : false;
    };

    $rootScope.root.saveUserToCookie = function (user) {
        return $cookieStore.put('user', user);
    };

    $rootScope.root.removeUserFromCookie = function () {
        $cookieStore.remove('user');
    };

    $rootScope.root.currentUser = function () {
        return $cookieStore.get('user');
    };

    $rootScope.root.isActive = function (url) {
        return url === $location.$$path;
    };

});

app.config(['$routeProvider', function ($routeProvider) {

    $routeProvider
        .when('/', {
            templateUrl: 'view/main.html'
        })
        .when('/login', {
            templateUrl: 'view/login.html'
        })
        .when('/logout', {
            template: '',
            controller: function ($scope, $location, $http, $cookieStore) {
                if (!$scope.root.isLogin()) {
                    $location.path('/');
                    return;
                }
                $http.post('/users/logout', {}).success(function (data) {

                    $scope.root.removeUserFromCookie();
                    $location.path('/');

                })
            }
        })
        .when('/items', {
            templateUrl: 'view/items.html'
        })
        .when('/items/:id', {
            templateUrl: 'view/updateItem.html'
        })
        .when('/items/create/new', {
            templateUrl: 'view/createItem.html'
        })
        .otherwise({
            redirectTo: '/'
        });
}]);
//$http(config).success(function(data,status,headers,config){}).error(function(data,status,headers,config){});
app.factory('data', function ($http, $q) {
    var data_ = {};
    return {
        getAllItems: function () {
            var defer = $q.defer();
            $http.get('/items').success(function (data) {
                data_.items = data.data;
console.log(data.data);
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {
                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            });
            return defer.promise;
        },
        createItem: function (item) {
            var defer = $q.defer();
            $http.post('/items', item).success(function (data) {
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {
                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            });
            return defer.promise;
        },
        deleteItem: function (itemId) {

            var defer = $q.defer();
            $http.delete('/items/' + itemId).success(function (data) {
                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {

                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            })
            return defer.promise;
        },
        updateItem: function (item) {
            var defer = $q.defer();
            $http.put('/items', item).success(function (data) {

                defer.resolve(arguments[0], arguments[1], arguments[2], arguments[3]);
            }).error(function (data) {

                defer.reject(arguments[0], arguments[1], arguments[2], arguments[3]);
            })
            return defer.promise;
        },
        cacheItems: function () {

            return data_.items;
        },
        getCacheItem: function (id) {
            var cacheData = this.cacheItems();
            var length = cacheData.length;
            for (var i = 0; i < length; i++) {

                if (cacheData[i].id == id) {
                    return cacheData[i];
                }
            }
            return null;
        }
    };
});

app.run(function ($rootScope,$location) {
    $rootScope.$on( "$routeChangeStart", function(event, next, current) {
        if ( !$rootScope.root.isLogin()) {
            event.preventDefault();
            // no logged user, we should be going to #login
            if ( next.templateUrl == "view/login.html" ) {
                // already going to #login, no redirect needed
            } else {
                // not going to #login, we should redirect now
                $location.path( "/login" );
            }
        }
    });
});

app.controller('mainController', function ($scope, data, $timeout, $location) {
    data.getAllItems().then(function (data) {
        if (data.type == 1) {
            $scope.items = data.data;
            $timeout(function () {
//                console.log($scope.items);
            }, 0);
        }
    })

    $scope.updateItem = function (item) {
        $location.path('/items/' + JSON.stringify(item));
    }
});

app.controller('updateItemController', function ($scope, data, $timeout, $routeParams,$location) {

    $scope.item = data.getCacheItem($routeParams.id);

    $scope.updateItem = function () {
        data.updateItem($scope.item).then(function (d) {
            if(d.type == 1) {
                $location.path('/');
            }
        });
    };

    $scope.deleteItem = function () {
        data.deleteItem($scope.item.id).then(function (d) {
            console.log(d);
            if(d.type == 1){
                $location.path('/');
            }
        })
    };
});

app.controller('loginFormController', function ($scope, data, $location,$http) {

    $scope.login = function (name,pass) {
        $http.post('/users/login',{username:name, password:pass}).success(function (d) {
            if(d.type == 1){
                $scope.root.saveUserToCookie(d.data);
                $location.path('/');
            }
        });
    };

});

app.controller('createItemController', function ($scope, data, $location, $timeout) {

    $scope.item = {};

    $scope.createItem = function () {
        data.createItem($scope.item).then(function (d) {
           if(d.type == 1){
               $location.path('/');
           }
        });
    };

});
