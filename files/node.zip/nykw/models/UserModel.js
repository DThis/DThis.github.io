/**
 * Created by gan on 14-9-19.
 */

function create(Waterline) {
    var User = Waterline.Collection.extend({

        identity: 'user',
        connection: 'main',

        attributes: {
            username: {
                type: 'string',
                unique: true
            },
            password: 'string'
        }
    });

    return User;
}


module.exports = create;