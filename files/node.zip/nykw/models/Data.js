/**
 * Created by gan on 14-9-19.
 */

var express = require('express'),
    _ = require('lodash'),
    app = express(),
    Waterline = require('waterline');
// Instantiate a new instance of the ORM
var orm = new Waterline();

//////////////////////////////////////////////////////////////////
// WATERLINE CONFIG
//////////////////////////////////////////////////////////////////

// Require any waterline compatible adapters here
var diskAdapter = require('sails-disk'),
    mysqlAdapter = require('sails-mysql');

// Build A Config Object
var config = {

    // Setup Adapters
    // Creates named adapters that have have been required
    adapters: {
        'default': diskAdapter,
        disk: diskAdapter,
        mysql: mysqlAdapter
    },

    // Build Connections Config
    // Setup connections using the named adapter configs
    connections: {
        main: {
            adapter: 'disk'
        },

        myLocalDisk: {
            adapter: 'disk'
        },

        myLocalMySql: {
            adapter: 'mysql',
            host: 'localhost',
            database: 'foobar'
        }
    },

    defaults: {
        migrate: 'alter'
    }

};


//////////////////////////////////////////////////////////////////
// WATERLINE MODELS
//////////////////////////////////////////////////////////////////

var User = require('./UserModel')(Waterline);
var Item = require('./ItemModel')(Waterline);
var Order = require('./OrderModel')(Waterline);


// Load the Models into the ORM
orm.loadCollection(User);
orm.loadCollection(Item);
orm.loadCollection(Order);


module.exports = function (cb) {

//////////////////////////////////////////////////////////////////
// START WATERLINE
//////////////////////////////////////////////////////////////////

// Start Waterline passing adapters in
    orm.initialize(config, function (err, models) {

        if (err) throw err;

        models.collections.user.create({username: "aa", password: "123"}, function (err) {
        });

        cb(err, models);

    });
};

//if(require.main === module){
//    console.log("ada");
//    module.exports();
//}else{
//    console.log("aa");
//    module.exports(function () {
//        console.log("ok");
//    });
//
//}

