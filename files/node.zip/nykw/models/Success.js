/**
 * Created by gan on 14-9-22.
 */

var Success = function (data) {
    this.type = 1;
    this.data = data;
};

Success.__proto__.create = function (data) {
    return new Success(data);
};

module.exports = Success;
