/**
 * Created by gan on 14-9-19.
 */

function create(Waterline) {
    var Item = Waterline.Collection.extend({

        identity: 'item',
        connection: 'main',

        attributes: {
            name: {
                type: 'string',
                required: true
            },
            des: 'string',
            img_url: 'string',
            app_url: 'string',
            play_count: {
                type: 'integer',
                defaultsTo: 0
            }
        }
    });

    return Item;
}

module.exports = create;