/**
 * Created by gan on 14-9-22.
 */

var Error = function (type,message,detail) {
    this.message = message;
    this.type = type;
    this.detail = detail;
    console.log(type);
};

var part = function (type,message){
    return function (detail) {
        return new Error(type,message,detail);
    }
};

Error.__proto__.Type = {
    connection : part(10001,"连接错误"),
    database : part(10002, "数据库错误"),
    request : part(10003, "请求错误")
};

module.exports = Error;
