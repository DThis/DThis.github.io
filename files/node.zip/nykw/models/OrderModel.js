/**
 * Created by gan on 14-9-22.
 */

function create(Waterline) {
    var Order = Waterline.Collection.extend({

        identity: 'order',
        connection: 'main',

        attributes: {
            name: 'string',
            list: 'json'
        }
    });

    return Order;
}

module.exports = create;