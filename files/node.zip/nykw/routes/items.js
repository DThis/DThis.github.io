/**
 * Created by gan on 14-9-23.
 */
var express = require('express');
var router = express.Router();
var Error = require('../models/Error');
var Success = require('../models/Success');

router.get('/:page(\\d+)?/:count(\\d+)?', function (req, res) {
    var page = parseInt(req.params['page']) || 0;
    var count = parseInt(req.params['count']) || 10;

    req.models.collections.item.find({skip: page * count, limit: count, sort: 'createdAt desc'}, function (err, list) {
//        console.log(arguments);
        if (err) {
            res.json(Error.Type.database(err));
        } else {
            res.json(Success.create(list));
        }
    });
});

router.post('/', function (req, res) {
    req.models.collections.item.create(req.body, function (err, item) {
        if (err) {
            res.json(Error.Type.database(err));
        }else{
            res.json(Success.create(item));
        }
    });
});

router.delete('/:id', function (req, res) {
//    console.log(req.body);
    req.models.collections.item.destroy({where: {id: req.params.id}}, function (err, items) {
        if (err || items.length === 0) {
            res.json(Error.Type.database(err || "被删除的数据不存在"));
        }else{
            res.json(Success.create(item));
        }
    });
});

router.put('/', function (req, res) {
    var updateData = {};
    req.body.name && (updateData.name = req.body.name);
    req.body.des && (updateData.des = req.body.des);
    req.body.img_url && (updateData.img_url = req.body.img_url);
    req.body.app_url && (updateData.app_url = req.body.app_url);
    req.models.collections.item.update({where: {id : req.body.id}}, updateData, function (err,list) {
        if(err){
            res.json(Error.Type.database(err));
        }else{
            res.json(Success.create(list));
        }
    });
});

module.exports = router;
