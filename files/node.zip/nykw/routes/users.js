var express = require('express');
var router = express.Router();
var Error = require('../models/Error');
var Success = require('../models/Success');


/* GET users listing. */
router.get('/', function (req, res) {

    req.models.collections.user.find(function (err, list) {
        if(err) {
            res.json(Error.Type.database(err));
        }else{
            res.json(Success.create(list));
        }
    })
});

router.post('/login', function (req, res) {
    req.models.collections.user.find({where: {username: req.body.username, password: req.body.password}}, function (err, users) {
        if (err || users.length != 1) {
            res.json(Error.Type.request(req.body));
        } else {
            req.session.user = users[0];
            res.json(Success.create(users[0]));

        }
    })
});

router.post('/logout', function (req,res) {
    req.session.destroy();
    res.json(Success.create(true));
});

router.get('/current', function (req, res) {
    res.json(Success.create(req.session.user));
});

module.exports = router;
