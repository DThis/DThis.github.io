# --- Created by Slick DDL
# To stop Slick DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table "CAT" ("name" VARCHAR(254) NOT NULL PRIMARY KEY,"color" VARCHAR(254) NOT NULL);
create table "headImage" ("uid" BIGINT NOT NULL PRIMARY KEY,"originUrl" VARCHAR(254) NOT NULL,"bigUrl" VARCHAR(254),"smallUrl" VARCHAR(254),"createAt" TIMESTAMP NOT NULL,"isDel" BOOLEAN DEFAULT false NOT NULL);
create table "user" ("uid" SERIAL NOT NULL PRIMARY KEY,"name" VARCHAR(254) NOT NULL,"pw" VARCHAR(254) NOT NULL,"email" VARCHAR(254) NOT NULL,"comment" VARCHAR(254),"updateAt" TIMESTAMP NOT NULL,"createAt" TIMESTAMP NOT NULL);
create unique index "idx_a" on "user" ("name");
create table "userToken" ("uid" BIGINT NOT NULL,"key" VARCHAR(254) NOT NULL,"platform" VARCHAR(254) NOT NULL,"ip" VARCHAR(254),"createAt" TIMESTAMP);

# --- !Downs

drop table "CAT";
drop table "headImage";
drop table "user";
drop table "userToken";

