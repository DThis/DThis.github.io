package test

import org.specs2.mutable._

import play.api.test._
import play.api.test.Helpers._
import play.api.libs.json.Json

/**
 * Created by gan on 14-7-10.
 */
class UserControllerSpec  extends Specification {
  "UserController" should {

    "访问login" in new WithApplication {
      val bodyData = Json.obj("name" -> "tt1404960840279", "pw" -> "pw")
      val loginPostRequest = FakeRequest(
        method = "POST",
        uri = "/logout",
        headers = FakeHeaders(Seq("Content-type"->Seq("application/json"))),
        body = bodyData)

      val Some(result) = route(loginPostRequest)

      status(result) must equalTo(OK)
    }
  }
}
