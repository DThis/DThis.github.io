package models

/**
 * Created by gan on 14-7-9.
 */

import play.api.db.slick.Config.driver.simple._
import play.api.libs.json.Json
import java.sql.Timestamp
import play.api.Logger

case class UserToken(var uid: Long,
                     var key: String,
                     var platform: String = "default",
                     var ip: Option[String],
                     var createAt: Option[Timestamp])

class UserTokenTable(tag : Tag) extends Table[UserToken] (tag , "userToken") {

  def uid = column[Long]("uid", O.NotNull)
  def key = column[String]("key", O.NotNull)
  def platform = column[String]("platform", O.NotNull)
  def ip = column[Option[String]]("ip", O.Nullable)
  def createAt = column[Option[Timestamp]]("createAt", O.Nullable)

  def * = (uid,key,platform,ip,createAt) <> (UserToken.tupled, UserToken.unapply _)

}

object UserTokens {
  implicit val userTokenFormat = Json.format[UserToken]

  val tokenExpireDate = 60 * 60 * 24 * 30

  val userTokens = TableQuery[UserTokenTable]

  /**
   *
   * @param uid
   * @param key
   * @param session
   * @return
   * @note 验证token是否正确，且在有效期
   */
  def authToken(uid : Long, key : String, platform : String)(implicit session : Session) : Boolean = {
    userTokens.filter(_.uid === uid).filter(_.key === key).filter(_.platform === platform).list.headOption.map { t =>
      t.createAt.map { date =>
        if (date.getTime - (new java.util.Date).getTime < UserTokens.tokenExpireDate) return true
      }
    }
    false
  }

  def generateToken(uid : Long, ip : Option[String] = None, platform : String = "default")(implicit session : Session) : Option[UserToken] = {

    val uuid = java.util.UUID.randomUUID.toString
    val time = new Timestamp(new java.util.Date().getTime)
    val token = UserToken(uid, uuid, platform, ip, Some(time))
    try {
      //      查看是否已存在此id
      userTokens.filter(_.uid === uid).filter(_.platform === platform).list.headOption.map { token =>
        //        Logger.info(userTokens.filter(_.uid === u.uid).map {_.key}.updateStatement.toString)
        userTokens.filter(_.uid === uid).map { t => (t.key, t.createAt, t.ip)}.update((uuid, Some(time), ip))
      }.getOrElse {
        //         userTokens += token
        userTokens.map(u => (u.uid, u.key, u.createAt, u.ip, u.platform)) +=(uid, uuid, Some(time), ip, platform)
      }
    }catch {
      case e : Exception => Logger.info(e.toString);return None
    }
    Some(token)
  }

  def deleteToken(uid : Long, key : String, platform : String)(implicit session : Session) : Option[Error] = {
    val userQuery = userTokens.filter(_.uid === uid).filter(_.key === key).filter(_.platform === platform)
    userQuery.list.headOption.map { t =>
      userQuery.delete
      Logger.info(userTokens.list.toString)
      None
    }.getOrElse{
      Some(Error.NotLogin)
    }


  }

}
