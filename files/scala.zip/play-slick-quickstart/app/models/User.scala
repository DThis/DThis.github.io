package models

import play.api.db.slick.Config.driver.simple._
import play.api.libs.json._
import javax.print.attribute.standard.DateTimeAtProcessing
import java.sql.Timestamp
import play.api.Logger
import play.api.Play.current
import play.api.db.DB
import play.api.db.slick.DB
import HeadImages._
import play.api.libs.json.Reads._
import play.api.libs.functional.syntax._


/**
 * Created by tz on 14-7-6.
 */
//case class Token(uid : Long,)
case class User(uid : Option[Long],
                var name : Option[String],
                var pw : Option[String],
                var email : Option[String],
                var comment : Option[String],
                var updateAt : Option[Timestamp],
                var createAt : Option[Timestamp])

class UserTable(tag : Tag) extends Table[User] (tag, "user") {

  def uid = column[Long]("uid", O.PrimaryKey, O.AutoInc)
  def name = column[String]("name", O.NotNull)
  def pw = column[String]("pw", O.NotNull)
  def email = column[String]("email", O.NotNull)
  def comment = column[Option[String]]("comment", O.Nullable)
  def updateAt = column[Timestamp]("updateAt", O.NotNull)
  def createAt = column[Timestamp]("createAt", O.NotNull)

  def idx = index("idx_a", name, unique = true)

  def * = (uid.?,name.?,pw.?,email.?,comment,updateAt.?,createAt.?) <> (User.tupled, User.unapply _ )

}




object Users {

//  implicit val userReads : Reads[User] = (
//    (JsPath \ "uid").readNullable[Long] and
//      (JsPath \ "name").read[String] and
//      (JsPath \ "pw").read[String] and
//      (JsPath \ "email").read(email) and
//      (JsPath \ "comment").readNullable[String] and
//      (JsPath \ "updateAt").readNullable[Timestamp] and
//      (JsPath \ "createAt").readNullable[Timestamp]
//    )(User.apply _)
//  implicit val userWrites : Writes[User] = Json.writes[User]
//  implicit val userformat = Format(userReads,userWrites)



  def auth(name : String, pw : String)(implicit s: Session) : Option[User] = {

    val users = TableQuery[UserTable]
//    users.filter(_.name === name).filter(_.pw === pw).selectStatement
    val user = users.filter(_.name === name).filter(_.pw === pw).list.headOption
    Logger.info(user.toString)
    user.map { u =>
      Some(u)
    }.getOrElse {
      None
    }
  }

}