/**
 * Created by tz on 14-7-8.
 */
package object models {
  import java.sql.Timestamp
  import play.api.libs.functional.syntax._
  import play.api.libs.json._

  implicit val rds: Reads[Timestamp] = (__ \ "time").read[Long].map{ long => new Timestamp(long) }
  implicit val wrs: Writes[Timestamp] = (__ \ "time").write[Long].contramap{ (a: Timestamp) => a.getTime }
  implicit val fmt: Format[Timestamp] = Format(rds, wrs)

  implicit val rdsOp: Reads[Option[Timestamp]] = (__ \ "time").read[Long].map{ long => Some(new Timestamp(long)) }
  implicit val wrsOp: Writes[Option[Timestamp]] = (__ \ "time").write[Long].contramap{ (a: Option[Timestamp]) => a.map { t => t.getTime}.getOrElse{0} }
  implicit val fmtOp: Format[Option[Timestamp]] = Format(rdsOp, wrsOp)
}
