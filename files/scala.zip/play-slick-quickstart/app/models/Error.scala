package models

import play.api.libs.json._
import play.api.libs.functional.syntax._

/**
 * Created by gan on 14-7-11.
 */
case class Error(code : Int, message : String, detail : Option[String] = None)

object Error {
  implicit val format = Json.format[Error]

  val NameOrPw = Error(10001,"用户名或密码错误")
  val CantGenerateToken = Error(10002,"无法创建key")
  val RequestData = Error(10003,"请求数据错误", _ : Option[String])
  val NotLogin = Error(10004,"没有登录,或者uid或者key错误")
  val UidOrKey = Error(10005,"uid或者key错误")
  val DataBase = Error(10006,"数据库错误", _ : Option[String])
}