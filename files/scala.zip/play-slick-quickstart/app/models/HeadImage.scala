package models

/**
 * Created by gan on 14-7-14.
 */

import play.api.db.slick.Config.driver.simple._
import play.api.libs.json._
import java.sql.Timestamp
import play.api.Logger
import scala.Some
import scala.Some
import scala.Some
import play.api.libs.functional.~

case class HeadImage(var uid : Option[Long],
                     var originUrl: String,
                     var bigUrl: Option[String],
                     var smallUrl: Option[String],
                     var createAt: Timestamp,
                     var isDel: Option[Boolean] = Some(false))

class HeadImageTable(tag : Tag) extends Table[HeadImage] (tag, "headImage") {
  def uid = column[Long]("uid", O.PrimaryKey, O.NotNull)
  def originUrl = column[String]("originUrl", O.NotNull)
  def bigUrl = column[String]("bigUrl", O.Nullable)
  def smallUrl = column[String]("smallUrl", O.Nullable)
  def createAt = column[Timestamp]("createAt", O.NotNull)
  def isDel = column[Boolean]("isDel", O.NotNull, O.Default(false))

  def * = (uid.?,originUrl,bigUrl.?,smallUrl.?,createAt,isDel.?) <> (HeadImage.tupled, HeadImage.unapply _)
}

object HeadImages {
  implicit val format = Json.format[HeadImage]
//  implicit val opFormat = Json.format[Option[HeadImage]]

}
