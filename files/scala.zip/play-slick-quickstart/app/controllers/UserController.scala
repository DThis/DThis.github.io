package controllers

/**
 * Created by tz on 14-7-6.
 */

import models._
import play.api._
import play.api.db.slick._
import play.api.db.slick.Config.driver.simple._
import play.api.data._
import play.api.data.Forms._
import play.api.mvc._
import play.api.Play.current
import play.api.mvc.BodyParsers._
import play.api.libs.json._
import play.api.libs.json.Json._
import java.sql.Timestamp
import models.UserTokens._
import play.api.libs.functional.syntax._

import scala.slick.driver.JdbcDriver.backend.Database
import play.api.libs.json.Reads._
import models.UserToken
import scala.Some
import models.User
import models.HeadImage
import play.api.data.Forms.list
import scala.Some
import models.UserToken
import models.User
import models.HeadImage

//import Database.dynamicSession
import scala.slick.jdbc.{StaticQuery => Q, GetResult}

object UserController extends Controller {

//  implicit val format = Json.format[User]
  import Users._
  import HeadImages._

  val usersTable = TableQuery[UserTable]
  val imagesTable = TableQuery[HeadImageTable]


  case class UserWithHeadData(uid : Option[Long],
                          var name : Option[String],
                          var pw : Option[String],
                          var email : Option[String],
                          var comment : Option[String],
                          var updateAt : Option[Timestamp],
                          var createAt : Option[Timestamp],
                          var head : Option[HeadImage])
  implicit val userWithHeadFormat = Json.format[UserWithHeadData]

  def list(count : Int, offset : Int) = DBAction { implicit rq =>

    val list = (for {
      (u,i) <- usersTable leftJoin imagesTable on (_.uid === _.uid)
    } yield (u,i.originUrl.?,i.bigUrl.?,i.smallUrl.?,i.createAt.?,i.isDel.?)).drop(offset).take(10).sortBy(_._1.uid.desc).list

    val users = list.map { l =>

      var headImage : Option[HeadImage] = None
      l._2.map { originUrl =>

        val headImage = HeadImage(None,originUrl,l._3,l._4,l._5.get,None)
        UserWithHeadData(l._1.uid,l._1.name,l._1.pw,l._1.email,l._1.comment,l._1.createAt,l._1.updateAt,Some(headImage))
      }.getOrElse{
        UserWithHeadData(l._1.uid,l._1.name,l._1.pw,l._1.email,l._1.comment,l._1.createAt,l._1.updateAt,None)
      }

    }

    Ok(Json.obj("success" -> true,"data" -> users))

  }

  /**
   *
   * @return
   */
  case class UserSaveData(var name: Option[String],
                          var pw: Option[String],
                          var email: String,
                          var comment: Option[String],
                          var updateAt: Option[Timestamp],
                          var createAt: Option[Timestamp])

  implicit val UserSaveDataReads: Reads[UserSaveData] = (
    (JsPath \ "name").read[Option[String]] and
      (JsPath \ "pw").read[Option[String]] and
      (JsPath \ "email").read(Reads.email) and
      (JsPath \ "comment").readNullable[String] and
      (JsPath \ "updateAt").readNullable[Timestamp] and
      (JsPath \ "createAt").readNullable[Timestamp]
    )(UserSaveData.apply _)
  implicit val UserSaveDataWrites: Writes[UserSaveData] = Json.writes[UserSaveData]
  implicit val UserSaveDataformat = Format(UserSaveDataReads, UserSaveDataWrites)

  def save = DBAction(parse.json) { implicit rs =>

//    implicit val format = Json.format[User]
//    rs.request.body.validate[User].map { user =>
//      val timeStamp = new Timestamp((new java.util.Date().getTime))
//      user.updateAt = Some(timeStamp)
//      user.createAt = Some(timeStamp)
//      try {
//        usersTable += user
//        Ok(obj("code" -> 1))
//      }catch {
//        case e : Exception => Ok(obj("errors" -> arr(Error.RequestData(Some(e.toString)))))
//      }
//
//    }.getOrElse(Ok(obj("code" -> 0)))

    rs.request.body.validate[UserSaveData].fold(
    invalid = { fieldErrors =>
      val errors = fieldErrors.map{x => s"field:${x._1},errors:${x._2.head.message}"}
//      Logger.info(Json.prettyPrint(Json.toJson(errors)))
      Ok(obj("errors" -> arr(Error.RequestData(Some(errors.toString)))))

    },
    valid = { userData =>
      val timeStamp = new Timestamp((new java.util.Date().getTime))
      val user = User(None,userData.name,userData.pw,Some(userData.email),userData.comment,Some(timeStamp),Some(timeStamp))

      try {
        usersTable += user
        Ok(obj("code" -> 1))
      }catch {
        case e : Exception => Ok(obj("errors" -> arr(Error.RequestData(Some(e.toString)))))
      }
    }
    )
  }

  case class UpdateData(uid: Long,
                        var name: Option[String],
                        var pw: Option[String],
                        var email: Option[String],
                        var comment: Option[String],
                        var key: String,
                        var platform: String)

  implicit val updateDataReads : Reads[UpdateData] = (
    (JsPath \ "uid").read[Long] and
      (JsPath \ "name").readNullable[String] and
      (JsPath \ "pw").readNullable[String] and
      (JsPath \ "email").readNullable(Reads.email) and
      (JsPath \ "comment").readNullable[String] and
      (JsPath \ "key").read[String] and
      (JsPath \ "platform").read[String]
    )(UpdateData.apply _)
  implicit val updateDataWrites : Writes[UpdateData] = Json.writes[UpdateData]

  def update(id : Long) = DBAction(parse.json) { implicit rs =>

    val json = rs.request.body
    json.validate[UpdateData].fold(
      invalid = { fieldErrors =>
        val errors = fieldErrors.map{x => s"field:${x._1},errors:${x._2.head.message}"}
              Logger.info(Json.prettyPrint(Json.toJson(errors)))
        Ok(obj("success" -> false ,"errors" -> arr(Error.RequestData(Some(errors.toString)))))
      },
      valid = { updateData =>

        val isLogin = UserTokens.authToken(updateData.uid,updateData.key,updateData.platform)
        if(isLogin){
          val timeStamp = new Timestamp((new java.util.Date().getTime))

//          val user = User(Some(updateData.uid),updateData.name,updateData.pw,updateData.email,updateData.comment, Some(timeStamp),None)
          try {

            val f = usersTable.filter(_.uid === updateData.uid).map(u => (u.name,u.email,u.pw,u.comment))
              .update((updateData.name.getOrElse(""),updateData.email.getOrElse(""),updateData.pw.getOrElse(""),updateData.comment))

            updateData.key = ""
            updateData.pw = None
            Ok(obj("success" -> true ,"data" -> updateData))
          }catch {
            case e : Exception => Ok(obj("success" -> false ,"errors" -> arr(Error.DataBase(Some(e.toString)))))
          }

        }else {
          Ok(obj("success" -> false ,"errors" -> arr(Error.UidOrKey)))
        }

      }
    )

  }

  case class LoginData(name : String, pw : String, platform : String = "default")
  implicit val loginDataFormat = Json.format[LoginData]

  def login = DBAction(parse.json) { implicit rs =>
    val json = rs.request.body
    json.validate[LoginData].map { loginData =>
//      检测用户是否存在
      val user = Users.auth(loginData.name, loginData.pw)

      user.map { u =>
//        如果存在，则回复token

        val tokenOp = UserTokens.generateToken(u.uid.getOrElse(0),None,loginData.platform)
        tokenOp.map { t =>
          Ok(Json.obj("data" -> t))
        }.getOrElse {
          Ok(Json.obj("errors"->Json.arr(Error.CantGenerateToken)))
        }


//        使用Session的方式
//        Ok(Json.obj("succees" -> true)).withSession("uid" -> u.uid.get.toString)
      }.getOrElse {
        Ok(Json.obj("errors"->Json.arr(Error.NameOrPw)))
      }
    }.getOrElse {
      Ok(Json.obj("errors"->Json.arr(Error.RequestData(Some(json.toString)))))
    }

    //改为fold
  }

  def logout = DBAction(parse.json) { implicit rs =>
//    使用Session的方式
//    Logger.info(rs.request.session.get("uid").toString)
//    Ok(Json.obj("succees" -> true)).withNewSession

    rs.request.body.validate[UserToken].map { t =>
      val error = UserTokens.deleteToken(t.uid,t.key,t.platform)
      error.map { e =>
        Ok(Json.obj("errors" -> Json.arr(Error.NotLogin)))
      }.getOrElse{
        Ok(Json.obj("succees" -> true))
      }
    }.getOrElse{
      Ok(Json.obj("errors" -> Json.arr(Error.RequestData(Some(rs.request.body.toString)))))
    }


  }
}
