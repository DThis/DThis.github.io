Activator template for Play Framework and the Slick database access library
This template helps building a classic web app or a JSON API

For a more complex example, see the [computer database sample](https://github.com/playframework/play-slick/tree/master/samples/computer-database)